import React, { useEffect, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlus } from '@fortawesome/free-solid-svg-icons'; // Import the plus icon

const Sidebar = ({ onChatClick }) => {
    const [conversations, setConversations] = useState([]);

    // Fetch conversations from the backend
    useEffect(() => {
        const fetchConversations = async () => {
            try {
                const response = await fetch('/api/conversations');
                const data = await response.json();
                if (Array.isArray(data)) {
                    setConversations(data);
                }
            } catch (error) {
                console.error('Error fetching conversations:', error);
            }
        };

        fetchConversations();
    }, []);

    // Function to handle creating a new conversation
    const handleNewConversation = async () => {
        try {
            const response = await fetch('/api/start_new_conversation', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
            });
            const newConversation = await response.json();
            if (newConversation && newConversation._id) {
                // Update the state to include the new conversation
                setConversations([...conversations, newConversation]);
            }
        } catch (error) {
            console.error('Error starting new conversation:', error);
        }
    };

    return (
        <div className="h-full bg-gray-200 dark:bg-gray-900 shadow-md p-4 relative">
            <p className="text-gray-800 dark:text-white">Previous Chats</p>
            <button
                onClick={handleNewConversation}
                className="absolute top-4 right-4 text-blue-500 hover:text-blue-600"
                aria-label="New Conversation"
            >
                <FontAwesomeIcon icon={faPlus} size="lg" /> {/* Plus icon */}
            </button>
            <ul className="mt-4 space-y-2">
                {conversations && conversations.length > 0 ? (
                    conversations.map((chat) => (
                        <li
                            key={chat._id}
                            onClick={() => onChatClick(chat)}
                            className="cursor-pointer hover:bg-gray-300 dark:hover:bg-gray-700 p-2 rounded text-gray-800 dark:text-white"
                        >
                            {chat.conversation.length > 0
                                ? chat.conversation[chat.conversation.length - 1].user
                                : 'No messages'}
                        </li>
                    ))
                ) : (
                    <p className="text-gray-500">No conversations available.</p>
                )}
            </ul>
        </div>
    );
};

export default Sidebar;
