// src/components/PreviousChats.js

import React from 'react';

const PreviousChats = ({ chats, onSelectChat }) => {
  return (
    <div className="p-4">
      <h2 className="text-lg font-semibold mb-2 text-gray-800 dark:text-white">Previous Chats</h2>
      <div className="flex flex-col space-y-2">
        {chats.length === 0 ? (
          <p className="text-gray-500 dark:text-gray-400">No previous chats available.</p>
        ) : (
          chats.map((chat, index) => (
            <div
              key={index}
              className="bg-white dark:bg-gray-700 p-2 rounded shadow cursor-pointer"
              onClick={() => onSelectChat(chat._id)} // Call onSelectChat with the chat ID
            >
              <h3 className="text-gray-700 dark:text-gray-200">
                {chat.conversation.length > 0
                  ? chat.conversation[chat.conversation.length - 1].user || "No user message"
                  : "No conversation available"}
              </h3>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default PreviousChats;

